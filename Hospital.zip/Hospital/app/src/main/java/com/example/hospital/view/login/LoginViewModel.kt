package com.example.hospital.view.login

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.hospital.R

class LoginViewModel : ViewModel() {
    private val _errorMessage = MutableLiveData<Int?>()
    val errorMessage: LiveData<Int?> = _errorMessage
    private val _loginSuccess = MutableLiveData<Boolean>()
    val loginSuccess: LiveData<Boolean> = _loginSuccess
    fun onLoginClicked(login: String, password: String){
        if(login.isNotBlank() && password.isNotBlank())
        {
//            if(answer == "ok")
//            {
//            }
//            else
//            {
//                _errorMessage.value = R.string.LogIncorrect
//            }
            if(login == "ui") {
                _loginSuccess.value = true
            }
        }
        else{

            _errorMessage.value = R.string.LogEmpty
        }
    }
}