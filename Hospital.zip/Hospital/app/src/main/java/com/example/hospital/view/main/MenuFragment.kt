package com.example.hospital.view.main

import android.content.Intent
import androidx.fragment.app.viewModels
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import com.example.hospital.view.main.AddConsultFragment
import com.example.hospital.R
import com.example.hospital.view.login.LoginActivity

class MenuFragment : Fragment() {

    companion object {
        fun newInstance() = MenuFragment()
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // TODO: Use the ViewModel
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_menu, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val btnAddConsult = view.findViewById<Button>(R.id.buttonAddConsult)
        btnAddConsult.setOnClickListener {
            openAddConsult()
        }
        val btnAddPat = view.findViewById<Button>(R.id.buttonAddPat)
        btnAddPat.setOnClickListener {
            openAddPatient()
        }
        val btnSearchConsult = view.findViewById<Button>(R.id.buttonSearchConsult)
        btnSearchConsult.setOnClickListener {
            openSearchConsult()
        }
        val btnLogout = view.findViewById<Button>(R.id.logoutButton)
        btnLogout.setOnClickListener {
            //TODO Requete de logout ICI AU DESSUS
            val intent = Intent(requireContext(), LoginActivity::class.java)
            startActivity(intent)
            requireActivity().finish()
        }
    }
    private fun openAddConsult(){
        parentFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, AddConsultFragment())
            .addToBackStack(null)
            .commit()
    }
    private fun openSearchConsult(){
        parentFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, MenuConsultFragment())
            .addToBackStack(null)
            .commit()
    }

    private fun openAddPatient(){
        parentFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, PatientFragment())
            .addToBackStack(null)
            .commit()
    }
}
