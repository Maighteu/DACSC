package com.example.hospital.view.main

import android.app.DatePickerDialog
import android.icu.util.Calendar
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.example.hospital.R

class GetDateFragment : Fragment() {
    private val viewModel: GetDateTimeViewModel by viewModels({ requireParentFragment() })

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_get_date, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val textView = view.findViewById<TextView>(R.id.text_getDate)
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        textView.setOnClickListener {
            val datePicker = DatePickerDialog(requireContext(), { _, y, m, d ->
                textView.text = getString(R.string.SelectedDate, y, m + 1, d)
                viewModel.year = y
                viewModel.month = m+1
                viewModel.day = d
            }, year, month, day)
            datePicker.show()
        }
    }


}