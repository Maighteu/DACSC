package com.example.hospital.view.main

import android.app.TimePickerDialog
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.viewModels
import com.example.hospital.R
import com.google.android.material.textfield.TextInputEditText
import java.util.Calendar
private var _hour = 0
private var _minute = 0

/**
 * A simple [Fragment] subclass.
 * Use the [UpdtConsultFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class UpdtConsultFragment : Fragment() {
    private val viewModel: GetDateTimeViewModel by viewModels()
    private var consultId: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        consultId = arguments?.getInt(ARG_CONSULT_ID) ?: -1
    }
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_updt_consult, container, false)
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        if (savedInstanceState == null) {
            childFragmentManager.beginTransaction()
                .replace(
                    R.id.addUpdateConsultDate,
                    GetDateFragment()
                )
                .commit()
        }
        val hourText = view.findViewById<TextView>(R.id.hourUpdt)
        hourText.setOnClickListener {
            showTimePicker(hourText)
        }
        val btnUpdate = view.findViewById<Button>(R.id.updateButton)
        btnUpdate.setOnClickListener {
            val inputReason = view.findViewById<TextInputEditText>(R.id.input_Reason)
            val reason = inputReason.text.toString().trim()
            val inputPatNom = view.findViewById<TextInputEditText>(R.id.input_ModifyNom)
            val patient = inputPatNom.text.toString().trim()

            Log.d("UpdtConsult", "Bouton Update Cliqué")
            Log.d(
                "UpdtConsult",
                "Date du ViewModel = year=${viewModel.year}, month=${viewModel.month}, day=${viewModel.day}, hour= $_hour, minute= $_minute reason= $reason, patient= $patient, id consult $consultId")
        }
    }
    private fun showTimePicker(target: TextView){
        val calendar = Calendar.getInstance()

        val hour = calendar.get(Calendar.HOUR_OF_DAY)
        val minute = calendar.get(Calendar.MINUTE)

        TimePickerDialog(
            requireContext(),
            {_,h,m ->
                val choice = String.format("%02d:%02d", h, m)
                _hour = h
                _minute = m
                target.text = choice
            },
            hour,
            minute,
            true
        ).show()
    }

    companion object {
        private const val ARG_CONSULT_ID = "consult_id"

        fun newInstance(id: Int): UpdtConsultFragment {
            val fragment = UpdtConsultFragment()
            val bundle = Bundle()
            bundle.putInt(ARG_CONSULT_ID, id)
            fragment.arguments = bundle
            return fragment
        }
    }


}