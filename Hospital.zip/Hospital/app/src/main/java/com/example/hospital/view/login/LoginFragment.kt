package com.example.hospital.view.login

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.example.hospital.R
import com.example.hospital.view.login.LoginViewModel
import com.example.hospital.view.main.MainActivity

/**
 * A simple [androidx.fragment.app.Fragment] subclass.
 * Use the [LoginFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class LoginFragment : Fragment() {

    private val viewModel: LoginViewModel by viewModels()
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_login, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {

        super.onViewCreated(view, savedInstanceState)
        val loginButton = view.findViewById<Button>(R.id.LogButton)
        val log = view.findViewById<EditText>(R.id.input_login)
        val pass =  view.findViewById<EditText>(R.id.input_password)
        val errorText = view.findViewById<TextView>(R.id.LogError)

        loginButton.setOnClickListener {
        viewModel.onLoginClicked(log.text.toString(), pass.text.toString())

        }
        viewModel.errorMessage.observe(viewLifecycleOwner) {
            errorResId ->
            if (errorResId != null){
                errorText.setText(errorResId)
            }
        }

        viewModel.loginSuccess.observe(viewLifecycleOwner){
            success -> if(success)
        {
            val intent = Intent(requireContext(), MainActivity::class.java)
            intent.putExtra("Login", log.text.toString())
            startActivity(intent)
            requireActivity().finish()
        }
        }
    }
}