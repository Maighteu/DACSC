package com.example.hospital.view.main

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TableLayout
import android.widget.TableRow
import android.widget.TextView
import androidx.fragment.app.viewModels
import com.example.hospital.R
import com.google.android.material.textfield.TextInputEditText

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER


/**
 * A simple [Fragment] subclass.
 * Use the [MenuConsultFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class MenuConsultFragment : Fragment() {
    private var _id :Int =0
    private val viewModel: GetDateTimeViewModel by viewModels()
    private var selectedRow: TableRow? = null   // ✅ ICI


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_menu_consult, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val table = view.findViewById<TableLayout>(R.id.tableMenuConsult)

        //TODO Inserer ici les valeurs récup lors de la recherche.
        //TODO ceci fait aussi le surlignage du parametre à envoyer dans modifier et delete
        val data = listOf(
            listOf("1", "Dupont", "Jean", "12/01/2026", "10:30"),
            listOf("2", "Martin", "Alice", "13/01/2026", "09:00"),
                    listOf("1", "Dupont", "Jean", "12/01/2026", "10:30"),
        listOf("2", "Martin", "Alice", "13/01/2026", "09:00"),
        listOf("1", "Dupont", "Jean", "12/01/2026", "10:30"),
        listOf("2", "Martin", "Alice", "13/01/2026", "09:00"),
        listOf("1", "Dupont", "Jean", "12/01/2026", "10:30"),
        listOf("2", "Martin", "Alice", "13/01/2026", "09:00"),
        listOf("1", "Dupont", "Jean", "12/01/2026", "10:30"),
        listOf("2", "Martin", "Alice", "13/01/2026", "09:00"),
        listOf("1", "Dupont", "Jean", "12/01/2026", "10:30"),
        listOf("2", "Martin", "Alice", "13/01/2026", "09:00"),
        listOf("1", "Dupont", "Jean", "12/01/2026", "10:30"),
        listOf("2", "Martin", "Alice", "13/01/2026", "09:00"),
            listOf("1", "Dupont", "Jean", "12/01/2026", "10:30"),
            listOf("2", "Martin", "Alice", "13/01/2026", "09:00"),
            listOf("1", "Dupont", "Jean", "12/01/2026", "10:30"),
            listOf("2", "Martin", "Alice", "13/01/2026", "09:00"),
            listOf("1", "Dupont", "Jean", "12/01/2026", "10:30"),
            listOf("2", "Martin", "Alice", "13/01/2026", "09:00"),

        )

        for (item in data) {
            //TODO Fait Attention, ici on défini chaque row mise dedans comme Clickable
            val row = TableRow(requireContext())
            row.isClickable = true
            row.isFocusable = true

            row.setOnClickListener {
                selectedRow?.setBackgroundColor(
                    requireContext().getColor(android.R.color.transparent)
                )

                row.setBackgroundColor(
                    requireContext().getColor(R.color.orange)
                )

                selectedRow = row
                val id = (row.getChildAt(0) as TextView).text.toString().toInt()
                val nom = (row.getChildAt(1) as TextView).text.toString()
                _id = id
                Log.d("MenuConsult", "ID=$id Nom=$nom")
            }
            for (value in item) {
                val tv = TextView(requireContext())
                tv.text = value
                tv.setPadding(8, 8, 8, 8)
                row.addView(tv)
            }

            table.addView(row)
        }

        if (savedInstanceState == null) {
            childFragmentManager.beginTransaction()
                .replace(
                    R.id.addConsultMenuDate,
                    GetDateFragment()
                )
                .commit()
        }
        val btnSearchConsult = view.findViewById<Button>(R.id.menuButtonSearch)
        btnSearchConsult.setOnClickListener {
            //ToDO si champ est "" pas de patient à rechercher, si Date = 0 0 0 pas de date à rechercher
            val inputPatName = view.findViewById<TextInputEditText>(R.id.input_ConsultNom)
            val nom = inputPatName.text.toString().trim()
            Log.d("SearchConsult", "Bouton Search Cliqué")
            Log.d(
                "SearchConsult",
                "Date du ViewModel = year=${viewModel.year}, month=${viewModel.month}, day=${viewModel.day}, nom = $nom")


        }

        val btnDelConsult = view.findViewById<Button>(R.id.menuButtonDel)
        btnDelConsult.setOnClickListener {
            //TODO ici le à delete est _id
        }
        val btnUpdateConsult = view.findViewById<Button>(R.id.menuButtonUpdate)
        btnUpdateConsult.setOnClickListener {
            openUpdateConsult()
        }

    }

    private fun openUpdateConsult()
    {
        Log.d("MenuConsult", "ID=$_id ")

        parentFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, UpdtConsultFragment.newInstance(_id))
            .addToBackStack(null)
            .commit()
    }


}

