package com.example.hospital.view.main
import androidx.lifecycle.ViewModel
import com.example.hospital.R
import java.util.Calendar

class GetDateTimeViewModel : ViewModel() {
    //Tout à 0 car si c'est à zero le champ n'a pas été selectionné
    var year: Int = 0
    var month:Int = 0
    var day: Int = 0
    //TODO Faire en sorte que le parent recup les infos
}