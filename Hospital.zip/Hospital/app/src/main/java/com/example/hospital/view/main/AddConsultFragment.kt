package com.example.hospital.view.main

import android.app.TimePickerDialog
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.example.hospital.R
import com.google.android.material.textfield.TextInputEditText
import org.intellij.lang.annotations.JdkConstants
import java.util.Calendar

class AddConsultFragment : Fragment() {
private var _hour = 0
private var _minute = 0
    private val viewModel: GetDateTimeViewModel by viewModels()


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_add_consult, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        if (savedInstanceState == null) {
            childFragmentManager.beginTransaction()
                .replace(
                    R.id.addConsultDate,
                    GetDateFragment()
                )
                .commit()
        }
        val hourText = view.findViewById<TextView>(R.id.hour)
        hourText.setOnClickListener {
            showTimePicker(hourText)
        }


        val btnAddingConsult = view.findViewById<Button>(R.id.ConsultHour)
        btnAddingConsult.setOnClickListener {
            val consultLengthInt = view.findViewById<TextInputEditText>(R.id.input_length)
            val length:Int = consultLengthInt.text?.toString()?.toIntOrNull() ?: 0
            val consultNbrInt = view.findViewById<TextInputEditText>(R.id.consultNbr)
            val nbr = consultNbrInt.text?.toString()?.toIntOrNull() ?: 0
            Log.d("AddConsult", "Bouton Add Cliqué")
            Log.d(
                "AddConsult",
                "Date du ViewModel = year=${viewModel.year}, month=${viewModel.month}, day=${viewModel.day} hour= $_hour Minutes= $_minute Durée = $length Nombre $nbr")
        }

    }

    private fun showTimePicker(target: TextView){
        val calendar = Calendar.getInstance()

        val hour = calendar.get(Calendar.HOUR_OF_DAY)
        val minute = calendar.get(Calendar.MINUTE)

        TimePickerDialog(
            requireContext(),
            {_,h,m ->
                val choice = String.format("%02d:%02d", h, m)
                _hour = h
                _minute = m
                target.text = choice
            },
            hour,
            minute,
            true
        ).show()
    }


}